package hr.java.vjezbe.entitet;

public interface Diplomski extends Visokoskolska {
	Student odrediStudentaZaRektorovuNagradu();
}
