package hr.java.vjezbe.entitet;

public record Dvorana(String naziv, String zgrada) {}
