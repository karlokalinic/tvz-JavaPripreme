package hr.java.vjezbe.entitet;

public sealed interface Online permits Ispit {
	void setNazivOnlineSoftvera(String nazivOnlineSoftvera);
}
